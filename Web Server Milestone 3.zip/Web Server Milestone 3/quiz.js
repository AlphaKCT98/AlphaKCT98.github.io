// Quiz logic for the self-assessment page.
// This file checks answers, calculates a score, and prints feedback on the same page.

// These variables grab the form, buttons, and result areas from quiz.html.
const quizForm = document.getElementById("quiz-form");
const resetButton = document.getElementById("reset-quiz");
const resultsSection = document.getElementById("quiz-results");
const resultSummary = document.getElementById("result-summary");
const resultDetails = document.getElementById("result-details");

// I kept the answer key in one place so the quiz is easier to update later.
const answerKey = {
  q1: {
    type: "text",
    accepted: ["dns", "domain name system"],
    correctAnswer: "DNS (Domain Name System)",
    explanation: "DNS is the naming system that helps browsers find the correct server address."
  },
  q2: {
    type: "single",
    accepted: "HTTP/1.1",
    correctAnswer: "HTTP/1.1",
    explanation: "HTTP/1.1 introduced persistent connections so one connection could handle more than one request."
  },
  q3: {
    type: "single",
    accepted: "HTTP/2",
    correctAnswer: "HTTP/2",
    explanation: "HTTP/2 is known for binary framing and multiplexing over a single connection."
  },
  q4: {
    type: "single",
    accepted: "The requested resource could not be found",
    correctAnswer: "The requested resource could not be found",
    explanation: "A 404 error means the server could not find the requested resource at that path."
  },
  q5: {
    type: "single",
    accepted: "Nginx",
    correctAnswer: "Nginx",
    explanation: "Nginx is especially known for speed, scalability, reverse proxy use, and event-driven design."
  },
  q6: {
    type: "multi",
    accepted: [
      "Manage encrypted HTTPS connections",
      "Serve HTML, CSS, images, and other files",
      "Work with back end systems such as APIs and databases"
    ],
    correctAnswer: "Serve HTML, CSS, images, and other files; Manage encrypted HTTPS connections; Work with back end systems such as APIs and databases",
    explanation: "Modern web servers commonly serve files, handle encrypted traffic, and connect users to applications or APIs."
  }
};

const questionText = {
  q1: "The system that translates domain names into server addresses is called _____.",
  q2: "Which HTTP version introduced persistent connections?",
  q3: "Which version of HTTP is known for multiplexing and a binary format?",
  q4: "What does a 404 status code usually mean?",
  q5: "Which web server software is especially known for speed, scalability, and an event-driven design?",
  q6: "Select every task that modern web servers commonly handle."
};

const questionLabels = {
  q1: "Question 1",
  q2: "Question 2",
  q3: "Question 3",
  q4: "Question 4",
  q5: "Question 5",
  q6: "Question 6"
};

// This makes the fill-in-the-blank answer less picky about capitalization or extra spaces.
function normalizeText(value) {
  return value.trim().toLowerCase().replace(/[^\w\s/]/g, "").replace(/\s+/g, " ");
}

function getSingleAnswer(name) {
  const selected = document.querySelector(`input[name="${name}"]:checked`);
  return selected ? selected.value : "";
}

function getMultiAnswer(name) {
  return Array.from(document.querySelectorAll(`input[name="${name}"]:checked`))
    .map((item) => item.value)
    .sort();
}

function answersMatchMulti(userAnswers, correctAnswers) {
  if (userAnswers.length !== correctAnswers.length) {
    return false;
  }
  const sortedCorrect = [...correctAnswers].sort();
  return userAnswers.every((value, index) => value === sortedCorrect[index]);
}

function createDetailCard(questionId, earnedPoint, userAnswerText, correctAnswerText, explanationText) {
  const wrapper = document.createElement("article");
  wrapper.className = `result-card ${earnedPoint ? "correct-card" : "incorrect-card"}`;

  const statusText = earnedPoint ? "Correct" : "Incorrect";

  wrapper.innerHTML = `
    <h3>${questionLabels[questionId]}: ${statusText}</h3>
    <p><strong>Question:</strong> ${questionText[questionId]}</p>
    <p><strong>Your answer:</strong> ${userAnswerText || "No answer provided"}</p>
    <p><strong>Correct answer:</strong> ${correctAnswerText}</p>
    <p><strong>Score:</strong> ${earnedPoint} / 1</p>
    <p class="result-explanation"><strong>Why:</strong> ${explanationText}</p>
  `;

  return wrapper;
}

// When the user submits the form, this section grades every question and prints the results.
quizForm.addEventListener("submit", function (event) {
  event.preventDefault();

  let totalScore = 0;
  const totalQuestions = Object.keys(answerKey).length;
  resultDetails.innerHTML = "";

  const q1Input = document.getElementById("q1").value;
  const normalizedQ1 = normalizeText(q1Input);
  const q1Correct = answerKey.q1.accepted.includes(normalizedQ1) ? 1 : 0;
  totalScore += q1Correct;
  resultDetails.appendChild(
    createDetailCard("q1", q1Correct, q1Input, answerKey.q1.correctAnswer, answerKey.q1.explanation)
  );

  ["q2", "q3", "q4", "q5"].forEach((questionId) => {
    const userAnswer = getSingleAnswer(questionId);
    const isCorrect = userAnswer === answerKey[questionId].accepted ? 1 : 0;
    totalScore += isCorrect;
    resultDetails.appendChild(
      createDetailCard(
        questionId,
        isCorrect,
        userAnswer,
        answerKey[questionId].correctAnswer,
        answerKey[questionId].explanation
      )
    );
  });

  const q6Answers = getMultiAnswer("q6");
  const q6Correct = answersMatchMulti(q6Answers, answerKey.q6.accepted) ? 1 : 0;
  totalScore += q6Correct;
  resultDetails.appendChild(
    createDetailCard(
      "q6",
      q6Correct,
      q6Answers.join("; "),
      answerKey.q6.correctAnswer,
      answerKey.q6.explanation
    )
  );

  const passed = totalScore >= 4;
  const percent = Math.round((totalScore / totalQuestions) * 100);

  resultSummary.className = `result-summary ${passed ? "pass-summary" : "fail-summary"}`;
  resultSummary.innerHTML = `
    <h2>${passed ? "Pass" : "Fail"}</h2>
    <p><strong>Total score:</strong> ${totalScore} / ${totalQuestions} (${percent}%)</p>
    <p><strong>Overall result:</strong> ${passed ? "You passed this self-assessment quiz." : "You did not pass this self-assessment quiz yet."}</p>
  `;

  resultsSection.hidden = false;
  resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
});

// This clears the quiz so the user can retake it without refreshing the whole page.
resetButton.addEventListener("click", function () {
  quizForm.reset();
  resultsSection.hidden = true;
  resultSummary.innerHTML = "";
  resultDetails.innerHTML = "";
  window.scrollTo({ top: 0, behavior: "smooth" });
});